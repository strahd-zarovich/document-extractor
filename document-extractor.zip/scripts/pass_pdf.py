#!/usr/bin/env python3
"""
pass_pdf.py — Orchestrate TXT → OCR-A → OCR-B for a single PDF.
Exit codes:
  0 = accepted (one of the passes wrote CSV)
  1 = all passes below threshold → caller may route to Manual Review
"""
from __future__ import annotations
import os, sys, subprocess

def run(cmd: list[str]) -> int:
    p = subprocess.run(cmd)
    return p.returncode

def main(pdf_path: str, csv_out: str, json_out: str, out_dir: str) -> int:
    # TXT failed to meet reliability → try OCR A, then always try OCR B
    rc_a = _run(["/app/scripts/pass_pdf_ocr_a.sh", pdf_path, csv_out, json_out, out_dir])

    # Always attempt OCR B as a second chance if TXT did not accept.
    # This ensures we actually exercise the second OCR strategy on hard docs.
    rc_b = _run(["/app/scripts/pass_pdf_ocr_b.sh", pdf_path, csv_out, json_out, out_dir])

    # If either OCR pass produced acceptable output, consider the PDF handled.
    if rc_a == 0 or rc_b == 0:
        return 0

    # Neither OCR pass produced acceptable output → let the caller move to Manual Review.
    return 1

if __name__ == "__main__":
    import sys, os
    from common import get_logger
    # Use RUN_LOG when present, else global fallback file
    log = get_logger(os.getenv("RUN_LOG"))
    try:
        sys.exit(main(*sys.argv[1:]))
    except SystemExit as e:
        raise
    except Exception:
        log.exception("Unhandled error in %s", os.path.basename(__file__))
        sys.exit(1)
