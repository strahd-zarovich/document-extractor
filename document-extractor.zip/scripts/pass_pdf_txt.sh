#!/usr/bin/env bash
set -e
exec python3 /app/scripts/pass_txt.py "$@"